function toggleFall() {
    document.querySelector('h1').innerText = "Fall in Asheville";
    document.querySelector('body').className = "fall";
}

function toggleWinter() {
    document.querySelector('h1').innerText = "Winter in Asheville";
    document.querySelector('body').className = "winter";
}

function toggleSpring() {
    document.querySelector('h1').innerText = "Spring in Asheville";
    document.querySelector('body').className = "spring";
}