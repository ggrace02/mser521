// Learn how to make an alert: https://www.w3schools.com/jsref/met_win_alert.asp

function sayHello() {
  // your code here...
}

function sayGoodbye() {
  // your code here...
}
