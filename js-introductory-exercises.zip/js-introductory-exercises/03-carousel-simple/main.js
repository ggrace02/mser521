function showCat() {
    console.log("This is a cat");
}

function showDog() {
    console.log("This is a dog");
}

function showBird() {
    console.log("This is a bird");
}

function showFish() {
    console.log("This is a fish");
}
