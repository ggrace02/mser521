// Variable Demo 1: Variables store data
// copy this code and run it in your browser console:
let x = 1;
let y = 6;
let z = 4;
x = 2;
z = x + y;
x = 4;
z = z + x;

console.log(x);
console.log(y);
console.log(z);


// Variable Demo 2: JavaScript is case-sensitive
// copy this code and run it in your browser console:
let a = 3;
let A = 33;
console.log(a);
console.log(A);
